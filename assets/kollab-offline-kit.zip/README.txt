KOLLAB YOUTH · YOUR NEXT LEVEL
Offline practice kit · November 6, 2026

1. Extract all files together.
2. Open index.html in a current browser. Do not open it inside the ZIP.
3. If a school device blocks local web pages, open workshop-kit.html or print it with staff support. A paper-and-pencil version needs no website.

No participant account, internet connection or AI subscription is needed for the core activities. External source links need the internet and follow their own policies. The optional 3D model needs a compatible tool.

Choices and fictional text stay only in the open tab. Closing or reloading clears them. Use Download my plan before leaving. On shared devices, decide with staff where downloads should go and remove personal copies when appropriate. Do not type names or private information.

Facilitation: use the Facilitator / offline kit chapter or workshop-kit.html for 5/15/30-minute guides and the printable process worksheet. Save or print it to paper for no-device use.

Independent educational experience, not an official USC admissions assessment or credential. Sources and current official links are in the experience. No job, admission, mentor or placement promise is made.
